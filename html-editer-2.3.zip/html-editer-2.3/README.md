# html-editer made possible by

[mini code editer](https://github.com/xem/miniCodeEditor)

# how to use
* 1 open index.html

* 2 type or paste a html code in the text area 

